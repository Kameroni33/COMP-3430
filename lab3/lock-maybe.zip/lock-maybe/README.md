Lock me maybe
=============

This package contains three files:

1. A `README.md` (you're reading me right now!)
2. A `Makefile` that builds the program
3. `lock-maybe.c`, your starting point. It counts up to the
   `#define`'d amount in each thread. It calls a lock function that...
   isn't implemented.
